# --- VIRA: AI-Based Visa Recommendation System (Bilingual Version) ---
import streamlit as st
import pandas as pd
import joblib

# Load model and label encoder
model = joblib.load("best_visa_model.pkl")
le = joblib.load("label_encoder.pkl")

# Step-by-step visa procedures (English + Tamil)
visa_steps = {
    "Work": [
        "✅ Verify eligibility and obtain a valid job offer.",
        "📄 Collect essential documents: passport, employment letter, qualifications, and police clearance.",
        "🩺 Complete required medical checks.",
        "💻 Apply online through the official embassy portal.",
        "💰 Pay the visa fee and schedule a biometrics appointment.",
        "📬 Await your visa decision."
    ],
    "Student": [
        "📚 Get admission to a recognized university or institution.",
        "📄 Prepare documents: passport, admission letter, bank statements, and academic certificates.",
        "💻 Apply for your student visa online.",
        "💰 Pay the application fee and book your biometric appointment.",
        "🎓 Attend interview if required and await your visa approval."
    ],
    "Visitor": [
        "🏖️ Confirm travel purpose (tourism, business, medical, etc.).",
        "📄 Collect passport, invitation letters (if any), and proof of funds.",
        "💻 Fill out the visitor visa form online.",
        "💰 Pay the fee and schedule biometrics if required.",
        "✈️ Wait for your visa decision and prepare for travel."
    ],
    "PR": [
        "🧾 Check eligibility through the official PR points system.",
        "📄 Prepare documents: passport, work proof, education certificates, and police clearance.",
        "💻 Create an online PR profile and submit your Expression of Interest (EOI).",
        "💰 Pay fees when invited and upload supporting documents.",
        "📬 Wait for your PR visa decision."
    ],
    "Family": [
        "👨‍👩‍👧 Confirm sponsorship by an eligible family member.",
        "📄 Collect documents: relationship proof, passport, and sponsor’s financial documents.",
        "💻 Submit your visa application online.",
        "💰 Pay the required fees and book your biometrics appointment.",
        "📬 Wait for visa processing and final decision."
    ],
    "Special": [
        "🎭 Verify that you qualify for a special visa (e.g., artist, diplomat, sportsperson).",
        "📄 Collect official invitation or nomination documents.",
        "💻 Apply online and attach all relevant evidence.",
        "💰 Pay fees and attend embassy appointments if needed.",
        "📬 Wait for visa approval and follow embassy updates."
    ]
}

# Tamil translations
visa_steps_tamil = {
    "Work": [
        "✅ தகுதி உறுதி செய்து செல்லுபடியாகும் வேலை வாய்ப்பைப் பெறவும்.",
        "📄 தேவையான ஆவணங்களைச் சேகரிக்கவும்: பாஸ்போர்ட், வேலைக் கடிதம், தகுதி சான்றிதழ்கள், போலீஸ் சான்றிதழ்.",
        "🩺 மருத்துவ பரிசோதனைகளை முடிக்கவும்.",
        "💻 தூதரகத்தின் இணைய தளத்தின் மூலம் ஆன்லைனில் விண்ணப்பிக்கவும்.",
        "💰 விசா கட்டணத்தை செலுத்தி, பயோமெட்ரிக் நேரத்தை முன்பதிவு செய்யவும்.",
        "📬 விசா முடிவுக்காக காத்திருக்கவும்."
    ],
    "Student": [
        "📚 அங்கீகரிக்கப்பட்ட பல்கலைக்கழகம் அல்லது கல்வி நிறுவனம் ஒன்றில் சேர்க்கை பெறவும்.",
        "📄 தேவையான ஆவணங்களைத் தயாரிக்கவும்: பாஸ்போர்ட், சேர்க்கை கடிதம், வங்கி அறிக்கை, கல்வி சான்றிதழ்கள்.",
        "💻 மாணவர் விசாவிற்காக ஆன்லைனில் விண்ணப்பிக்கவும்.",
        "💰 கட்டணத்தை செலுத்தி, பயோமெட்ரிக் நேரத்தை முன்பதிவு செய்யவும்.",
        "🎓 தேவையெனில் நேர்காணலுக்கு செல்லவும் மற்றும் முடிவுக்காக காத்திருக்கவும்."
    ],
    "Visitor": [
        "🏖️ பயண நோக்கத்தை உறுதி செய்யவும் (சுற்றுலா, தொழில், மருத்துவம்).",
        "📄 பாஸ்போர்ட், அழைப்புக் கடிதங்கள் (இருப்பின்), நிதி ஆதாரங்கள் சேகரிக்கவும்.",
        "💻 ஆன்லைனில் விண்ணப்பத்தை நிரப்பவும்.",
        "💰 கட்டணத்தை செலுத்தி, தேவையெனில் பயோமெட்ரிக் நேரம் பதிவு செய்யவும்.",
        "✈️ விசா முடிவுக்காக காத்திருந்து, பயணத்துக்குத் தயாராகவும்."
    ],
    "PR": [
        "🧾 அதிகாரப்பூர்வ புள்ளி முறை மூலம் தகுதியை சரிபார்க்கவும்.",
        "📄 தேவையான ஆவணங்கள்: பாஸ்போர்ட், வேலைச் சான்று, கல்வி சான்றிதழ்கள், போலீஸ் சான்றிதழ்.",
        "💻 ஆன்லைனில் ஒரு PR சுயவிவரத்தை உருவாக்கி EOI சமர்ப்பிக்கவும்.",
        "💰 அழைப்பு கிடைத்தவுடன் கட்டணம் செலுத்தி ஆவணங்களைப் பதிவேற்றவும்.",
        "📬 விசா முடிவுக்காக காத்திருக்கவும்."
    ],
    "Family": [
        "👨‍👩‍👧 தகுதியான குடும்ப உறுப்பினரால் ஸ்பான்சர் செய்யப்படுவது உறுதி செய்யவும்.",
        "📄 ஆவணங்கள்: உறவு சான்று, பாஸ்போர்ட், ஸ்பான்சர் நிதி ஆதாரங்கள்.",
        "💻 ஆன்லைனில் விண்ணப்பத்தைச் சமர்ப்பிக்கவும்.",
        "💰 கட்டணத்தை செலுத்தி பயோமெட்ரிக் நேரத்தை முன்பதிவு செய்யவும்.",
        "📬 விசா முடிவுக்காக காத்திருக்கவும்."
    ],
    "Special": [
        "🎭 சிறப்பு விசா (கலைஞர், தூதர், விளையாட்டு வீரர்) தகுதி உறுதி செய்யவும்.",
        "📄 அழைப்புக் கடிதம் அல்லது பரிந்துரை ஆவணங்களைச் சேகரிக்கவும்.",
        "💻 ஆன்லைனில் விண்ணப்பித்து தேவையான சான்றுகளை இணைக்கவும்.",
        "💰 கட்டணத்தை செலுத்தி தேவையெனில் தூதரக சந்திப்பில் பங்கேற்கவும்.",
        "📬 விசா ஒப்புதலுக்காக காத்திருந்து புதுப்பிப்புகளைப் பின்தொடரவும்."
    ]
}

# UI
st.title("🇱🇰 VIRA – AI-Based Visa Recommendation System")
st.subheader("Visa Type Prediction and Application Guidance (English & Tamil)")

# User input fields (example)
age = st.number_input("Age", 18, 70)
work_experience_years = st.number_input("Work Experience (Years)", 0, 40)
education_level = st.number_input("Education Level (Encoded)", -3.0, 3.0, 0.0)
financial_status = st.number_input("Financial Status (Encoded)", -3.0, 3.0, 0.0)
purpose_of_travel = st.number_input("Purpose of Travel (Encoded)", -3.0, 3.0, 0.0)
language_proficiency = st.number_input("Language Proficiency (Encoded)", -3.0, 3.0, 0.0)

if st.button("Recommend Visa"):
    # Create DataFrame for prediction
    features = pd.DataFrame([[purpose_of_travel, age, 0, work_experience_years, 0, 0, 0,
                              education_level, 0, 0, financial_status, 0, 0, 0, language_proficiency]],
                            columns=[col for col in model.feature_names_in_])
    
    pred = model.predict(features)
    visa_type = le.inverse_transform(pred)[0]
    
    st.success(f"✅ Recommended Visa Type: **{visa_type} Visa**")
    
    # Display step-by-step guide
    st.subheader("🪄 Application Procedure (English)")
    for step in visa_steps.get(visa_type, ["No data available."]):
        st.write(step)
    
    st.subheader("🇱🇰 விசா விண்ணப்பிக்கும் நடைமுறை (Tamil)")
    for step in visa_steps_tamil.get(visa_type, ["தகவல் இல்லை."]):
        st.write(step)
